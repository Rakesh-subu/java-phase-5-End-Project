package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NewTest {

    WebDriver wd;

    @BeforeTest
    public void initiate() {
        System.out.println("config initiated");
        WebDriverManager.chromedriver().setup();
        wd = new ChromeDriver();
        wd.manage().window().maximize();
    }

    @Test(priority = 1)
    public void navigateToHomePage() {
        System.out.println("test1 initiated");
        wd.get("https://www.flipkart.com/");
        String expectedTitle = "Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!";
        Assert.assertEquals(wd.getTitle(), expectedTitle, "Incorrect page title");
    }

    @Test(priority = 2)
    public void measurePageLoadTime() {
        System.out.println("test2 initiated");
        long startTime = System.currentTimeMillis();
        // Perform any actions that might load the page
        long endTime = System.currentTimeMillis();
        long pageLoadTime = endTime - startTime;
        System.out.println("Page Load Time: " + pageLoadTime + " milliseconds");
    }

    @Test(priority = 3)
    public void searchOnFlipkart() throws InterruptedException {
        System.out.println("test3 initiated");
        WebElement searchBox = wd.findElement(By.name("q"));
        searchBox.sendKeys("iphone13");
        searchBox.sendKeys(Keys.RETURN);
        // Wait for search results to load
        WebDriverWait wait = new WebDriverWait(wd, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div._1AtVbE")));
        Assert.assertTrue(wd.getTitle().toLowerCase().contains("iphone13"), "Search results page does not contain the expected keyword");
        Thread.sleep(1000);
    }
    @Test(priority = 4)
    public void verifyLazyLoading() {
        JavascriptExecutor js = (JavascriptExecutor) wd;
        long originalHeight = (long) js.executeScript("return Math.max(document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight)");
        System.out.println("Original Page Height: " + originalHeight);

        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

        // Additional verification steps for lazy loading...

        waitForPageToLoad(originalHeight);

        long newHeight = (long) js.executeScript("return Math.max(document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight)");
        System.out.println("New Page Height: " + newHeight);

        Assert.assertNotEquals(originalHeight, newHeight, "Page did not scroll to the bottom");
    }

    private void waitForPageToLoad(long initialHeight) {
        WebDriverWait wait = new WebDriverWait(wd, 60);
        wait.until(driver -> {
            long newHeight = (long) ((JavascriptExecutor) driver).executeScript("return Math.max(document.body.scrollHeight, document.body.offsetHeight, document.documentElement.clientHeight, document.documentElement.scrollHeight, document.documentElement.offsetHeight)");
            System.out.println("Current Page Height: " + newHeight);
            return newHeight > initialHeight;
        });
    }



    @AfterTest
    public void derefer() {
        System.out.println("wd closed");
        wd.close();
    }
}
